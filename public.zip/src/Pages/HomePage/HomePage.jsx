export default function HomePage() {
  return <h2>Главная страница</h2>;
}
